package com.example.myapplication;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("/c/9fa5-60b9-4675-a0a0")
    Call<Books> getBook();
}
